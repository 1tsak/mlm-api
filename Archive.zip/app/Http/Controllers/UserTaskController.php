<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Task;
use App\Models\Earning;
use Illuminate\Support\Facades\Auth;

class UserTaskController extends Controller
{
    public function fetchTasks()
    {
        $tasks = Task::all();
        return response()->json($tasks, 200);
    }

    public function completeTask(Request $request, Task $task)
    {
        $user = Auth::user();

        // Check if the user has already completed the task
        if ($user->earnings()->where('task_id', $task->id)->exists()) {
            return response()->json(['message' => 'Task already completed'], 400);
        }

        // Create an earning record for the user
        Earning::create([
            'user_id' => $user->id,
            'task_id' => $task->id,
            'amount' => $task->reward
        ]);

        // Update user's balance
        $user->balance += $task->reward;
        $user->save();

        // Distribute rewards to referral levels
        $this->distributeRewards($user, $task->reward);

        return response()->json(['message' => 'Task completed successfully'], 201);
    }

    private function distributeRewards($user, $reward)
    {
        $levelPercentages = [0.1, 0.05, 0.03]; // Example percentages for levels 1, 2, and 3
        $currentLevel = 0;

        while ($user->sponsor_id && $currentLevel < count($levelPercentages)) {
            $sponsor = User::find($user->sponsor_id);

            if ($sponsor) {
                $levelReward = $reward * $levelPercentages[$currentLevel];
                $sponsor->balance += $levelReward;
                $sponsor->save();

                Earning::create([
                    'user_id' => $sponsor->id,
                    'amount' => $levelReward
                ]);
            }

            $user = $sponsor;
            $currentLevel++;
        }
    }
}
